class Status {
  String? status = "OK";
  String? message = "";

  Status({this.status, this.message});
}
