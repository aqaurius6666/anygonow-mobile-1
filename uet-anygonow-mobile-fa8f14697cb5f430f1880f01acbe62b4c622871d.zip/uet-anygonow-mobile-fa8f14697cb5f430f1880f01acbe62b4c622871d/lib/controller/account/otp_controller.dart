import 'package:timer_count_down/timer_controller.dart';

class OTPController {
  CountdownController countdownController =
  CountdownController(autoStart: true);
}
